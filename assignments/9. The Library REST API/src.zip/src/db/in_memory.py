from src.db.storage import load_books_json

books = load_books_json()
