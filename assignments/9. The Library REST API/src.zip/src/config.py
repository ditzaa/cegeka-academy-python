class Config:
    APP_NAME = "The Library REST API"
    VERSION = "1.0.1"
    DEBUG = True
    PORT = 5000
    JSON_PATH = "./db/books.json"
