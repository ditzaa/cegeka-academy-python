class BookNotBorrowedError(Exception):
    pass