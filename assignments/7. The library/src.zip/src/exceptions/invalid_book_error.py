class InvalidBookError(Exception):
    pass