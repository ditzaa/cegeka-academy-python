class InvalidAuthorError(Exception):
    pass