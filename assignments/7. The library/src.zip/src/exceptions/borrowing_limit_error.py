class BorrowingLimitError(Exception):
    pass
