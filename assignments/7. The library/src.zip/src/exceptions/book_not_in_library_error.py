class BookNotExistsError(Exception):
    pass