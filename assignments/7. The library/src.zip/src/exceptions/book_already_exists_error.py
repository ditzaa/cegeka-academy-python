class BookAlreadyExistsError(Exception):
    pass