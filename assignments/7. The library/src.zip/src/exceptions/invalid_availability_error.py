class InvalidAvailabilityError(Exception):
    pass