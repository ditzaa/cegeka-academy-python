class BookAlreadyBorrowedError(Exception):
    pass